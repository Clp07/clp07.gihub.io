var div=document.createElement("div"); 
document.body.appendChild(div); 

var htmlText = "<div style=\"display: flex; flex-direction: row; margin-top: 10px; padding: 5px; align-items: center; justify-content: center; background-color: #959595;\">\n<button onclick=\"Verifie(0)\" style=\"margin: 5px\">Valider cette question</button>\n<button style=\"margin: 5px\" onclick=\"Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);Verifie(0);\">Valider tout le QCM</button>\n<button style=\"margin: 5px\" onclick=\"temps += 30\">Ajouter 30s</button>\n<button style=\"margin: 5px\" onclick=\"temps = 1000000000\">Temps infini</button>\n</div>"

div.insertAdjacentHTML( 'beforeend', htmlText );